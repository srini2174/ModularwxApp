.. meta::
    :description: Names of those who developed and contributed to <project>.

======
People
======


Software Development
--------------------

- <author>


Contributors
------------

- Names of the contributors


Advisors
--------

- Name of the advisor
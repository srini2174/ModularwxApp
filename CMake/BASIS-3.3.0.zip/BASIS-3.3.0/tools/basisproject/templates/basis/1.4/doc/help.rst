.. meta::
    :description: Report any issues with <project> or request new features on GitHub.

=======
Support
=======

Please report any issues with <project>, including bug reports, feature requests,
or support questions, using the `GitHub issue tracker <https://github.com/<vendor>/<project>/issues>`__.

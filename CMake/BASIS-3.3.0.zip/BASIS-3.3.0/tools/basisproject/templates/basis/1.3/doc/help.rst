.. title:: Help

.. meta::
    :description: Report any issues with <project> or request new features on GitHub.

============
Getting Help
============

Please report any issues with <project>, including bug reports, feature requests,
or support questions, on `GitHub <https://github.com/<github-user>/<project_l>/issues>`__.

/**
 * @file  helloc++.cxx
 * @brief The not so typical Hello World! example program.
 */

#include <iostream>


// acceptable in .cxx file
using namespace std;


// ---------------------------------------------------------------------------
int main(int, char**)
{
    cout << "How is it going?" << endl;
    return 0;
}

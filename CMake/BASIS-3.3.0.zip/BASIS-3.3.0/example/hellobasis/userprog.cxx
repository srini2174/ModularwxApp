#include <iostream>
#include <hellotoplevel/moda.h>

int main(int, char**)
{
  std::cout << "Trying ModA?" << std::endl;
  hellotoplevel::moda();

  return 0;
}

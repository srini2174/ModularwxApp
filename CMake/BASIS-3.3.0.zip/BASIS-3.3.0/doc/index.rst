:orphan:

.. title:: Home

.. include:: intro.rst
.. include:: features.rst

Get Started
===========

1. Get your first taste with the :doc:`quickstart` guide.
2. Check out the :doc:`howto` for easy introductions to common tasks.
3. Learn more :doc:`About CMake BASIS <about>`, where it came from and why.
4. Investigate the :doc:`reference` and :doc:`API <apidoc>` for more in-depth information.
